#!/system/bin/sh
MODDIR=${0%/*}
KeyboxXML=/data/adb/tricky_store/keybox.xml
cd ${MODDIR}
curl -s "https://keybox.tonyha7.com/" > new.html

if [ -f old.html ] && diff -q old.html new.html > /dev/null; then
    echo "云端Keybox未更新"
    exit 0
fi

mv new.html old.html

if [ -f keybox.zip ]; then
    rm keybox.zip
fi

if [ -d keybox ]; then
    rm -rf keybox
fi

curl -s -O "https://keybox.tonyha7.com/keybox.zip"
unzip -o keybox.zip
if [ -f "$KeyboxXML" ]; then
    rm "$KeyboxXML"
fi
KBXML=$(find "keybox" -name "*.xml" | head -n 1)
cp "$KBXML" "$KeyboxXML"
killall com.google.android.gms.unstable
echo "Keybox更新完成"