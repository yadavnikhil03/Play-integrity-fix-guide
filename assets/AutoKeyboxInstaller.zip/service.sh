#!/system/bin/sh
MODDIR=${0%/*}

chmod +x ${MODDIR}/*.sh

(
until [ $(getprop sys.boot_completed) == 1 ] ; do
    sleep 20
done
${MODDIR}/keybox.sh
)&